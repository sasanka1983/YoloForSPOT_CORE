from __future__ import print_function
import cv2
import numpy as np
from elements.yolo import OBJ_DETECTION
import sys
import os,datetime
import argparse
import os
import sys
import time
import argparse

from threading import  Thread
import cv2
import numpy as np

from AsyncRobotState import AsyncRobotState

import bosdyn.client
import bosdyn.client.util
import bosdyn.geometry

from bosdyn import geometry
from bosdyn.api import geometry_pb2 as geo
from bosdyn.api import  trajectory_pb2

from bosdyn.api.spot import robot_command_pb2 as spot_command_pb2
from bosdyn.client.async_tasks import  AsyncTasks
from bosdyn.client.frame_helpers import ( VISION_FRAME_NAME, get_vision_tform_body)

from bosdyn.client.lease import LeaseKeepAlive
from bosdyn.client.math_helpers import Quat
from bosdyn.client.robot_command import (CommandFailedError, CommandTimedOutError,
                                         RobotCommandBuilder, RobotCommandClient, blocking_stand)
from bosdyn.client.robot_state import RobotStateClient


LOGGER = bosdyn.client.util.get_logger()

class SpotOperationWithYolo: 

	def __init__(self,config):

		
		self.config=config
		
		
		self.Object_classes = [ 'traffic light',
                        'fire hydrant', 'stop sign', 'backpack', 'umbrella', 'handbag', 'tie', 'suitcase', 'bottle', 'wine glass', 'cup', 'fork', 'knife', 'spoon', 'bowl', 'banana', 'apple',
                        'potted plant', 'bed', 'tv', 'laptop', 'mouse', 'remote', 'keyboard', 'cell phone',
                        'book', 'clock', 'vase', 'scissors', 'teddy bear' ]
		print("COCO Classes loaded")				
		
		self.Object_colors = list(np.random.rand(80,3)*255)
		self.Object_detector = OBJ_DETECTION('weights/yolov5s.pt', self.Object_classes)
		print("YOLO Model loaded")	
		if not (self.config.savePath=="" or self.config.savePath==None):
			
			if(not os.path.exists(self.config.savePath)):
				os.makedirs(self.config.savePath)
				print("directory created to save images")
		
		print("all variables loaded")
		print("power on the spot and make it stand tall")
		self.setup_and_power_on_spot(self.config)
		print("spot powered on and stood still. Ready to operate")

	def send_command_to_robot(self,x_goal,y_goal,label,end_time):
		robot_state = self.robot_state_task.proto
		tag_cmd = self.get_go_to(x_goal,y_goal, robot_state, self.get_mobility_params())
		if tag_cmd is not None:
			if not self.config.test_mode:
				print("executing command")
				self.robot_command_client.robot_command(lease=None, command=tag_cmd,
													end_time_secs=time.time() + end_time)
			else:
				print("Running in test mode, skipping command.")
		else:
			print(f"unable to build the robot command for the {label}")

	

	def detect_and_operate(self,cameraSource, cameraSourceId):
		if cameraSource=="SpotCams":
			cap = cv2.VideoCapture(self.__gstreamer_pipeline(flip_method=0), cv2.CAP_GSTREAMER)
		elif cameraSource=="USB":
			cap=cv2.VideoCapture(cameraSourceId)
			cap.set(cv2.cv.CV_CAP_PROP_FRAME_WIDTH, 640)
			cap.set(cv2.cv.CV_CAP_PROP_FRAME_HEIGHT, 480)
		else:
			print("Camera source not found")
			self.power_off_spot()
		# 
		print("capturing video")	
		if cap.isOpened():
			print("Reading from Camera")
			#window_handle = cv2.namedWindow("CSI Camera", cv2.WINDOW_AUTOSIZE)
			try:
				while True:#cv2.getWindowProperty("CSI Camera",0)>=0:
					
                   
					# print("camera is available")
					ret, frame = cap.read()
					if ret:
						# detection process
						#print("frame is available")
						objs = self.Object_detector.detect(frame)
						# plotting
						upload_image=False
						for obj in objs:
							# print(obj)
							label = obj['label']
							score = obj['score']
							if(score>.40):
								print(f"object {label} with greater than 40 percent confidence is detected")
								upload_image=True
								[(xmin,ymin),(xmax,ymax)] = obj['bbox']
								color = self.Object_colors[self.Object_classes.index(label)]
								frame = cv2.rectangle(frame, (xmin,ymin), (xmax,ymax), color, 2) 
								frame = cv2.putText(frame, f'{label} ({str(score )})', (xmin,ymin), cv2.FONT_HERSHEY_SIMPLEX , 0.75, color, 1, cv2.LINE_AA)
								end_time = 15.0
								if label=="cell phone":
									self.send_command_to_robot(10,0,label,end_time)
									
								elif label=="backpack":
									self.send_command_to_robot(-10,0,label,end_time)
								elif label=="laptop":
									self.send_command_to_robot(0,10,label,end_time)
								elif label== "stop sign":
									bosdyn.client.robot_command.stop_command()
									bosdyn.client.robot_command.selfright_command()
						#cv2.imshow("CSI Camera",frame)
						
						if not self.config.savePath=="":
							print("uploading image to azure")
							this_moment=datetime.datetime.now()
							filename=("received_image_{year:x}{month:x}{day:x}{hour:x}{minute:x}{sec:x}.jpg".format(year=this_moment.year,month=this_moment.month,day=this_moment.day,hour=this_moment.hour,minute=this_moment.minute,sec=this_moment.second))
							filepath=os.path.join(self.config.savePath,filename)
							cv2.imwrite(filepath,frame)
							
						#keyCode= cv2.waitKey(30)
						#if keyCode==ord("q"):
							#break
			except KeyboardInterrupt:
				cap.release()
				cv2.destroyAllWindows()
			except:
				print("error occurred")
				cap.release()
				cv2.destroyAllWindows()                 
		else:
			print("unable to read camera")                

	def setup_and_power_on_spot(self,config):
	
		# The Boston Dynamics Python library uses Python's logging module to
		# generate output. Applications using the library can specify how
		# the logging information should be output.
		bosdyn.client.util.setup_logging(config.verbose)
		sdk = bosdyn.client.create_standard_sdk('HelloSpotClient')
		self.robot = sdk.create_robot(config.hostname)
		bosdyn.client.util.authenticate(self.robot)
		self.robot.time_sync.wait_for_sync()
		assert not self.robot.is_estopped(), "Robot is estopped. Please use an external E-Stop client, such as the estop SDK example, to configure E-Stop."
		
		self.command_client = self.robot.ensure_client(RobotCommandClient.default_service_name)
		self.robot_state_client=self.robot.ensure_client(RobotStateClient.default_service_name)
		self.robot_state_task= AsyncRobotState(self.robot_state_client,LOGGER)
		task_list = [self.robot_state_task]
		_async_tasks = AsyncTasks(task_list)

		lease_client = self.robot.ensure_client(bosdyn.client.lease.LeaseClient.default_service_name).take()
		self.leaseKeep= LeaseKeepAlive(lease_client)
		self.robot.logger.info("Powering on robot... This may take several seconds.")
		self.robot.power_on(timeout_sec=20)
		assert self.robot.is_powered_on(), "Robot power on failed."
		self.robot.logger.info("Robot powered on.")

		self.robot.logger.info("Commanding robot to stand...")

		try:
			blocking_stand(self.command_client)
		except CommandFailedError as exc:
			print(f'Error ({exc}) occurred while trying to stand. Check robot surroundings.')
			return False
		except CommandTimedOutError as exc:
			print(f'Stand command timed out: {exc}')
			return False
		print('Robot powered on and standing.')
		

		# This thread starts the async tasks for image and robot state retrieval
		update_thread = Thread(target=self._update_thread, args=[_async_tasks])
		update_thread.daemon = True
		update_thread.start()
		# Wait for the first responses.
		while any(task.proto is None for task in task_list):
			time.sleep(0.1)
		# Tell the robot to stand in a twisted position.
		#
		# The RobotCommandBuilder constructs command messages, which are then
		# issued to the robot using "robot_command" on the command client.
		#
		# In this example, the RobotCommandBuilder generates a stand command
		# message with a non-default rotation in the footprint frame. The footprint
		# frame is a gravity aligned frame with its origin located at the geometric
		# center of the feet. The X axis of the footprint frame points forward along
		# the robot's length, the Z axis points up aligned with gravity, and the Y
		# axis is the cross-product of the two.
		footprint_R_body = bosdyn.geometry.EulerZXY(yaw=0.4, roll=0.0, pitch=0.0)
		cmd = RobotCommandBuilder.synchro_stand_command(footprint_R_body=footprint_R_body)
		self.command_client.robot_command(cmd)
		self.robot.logger.info("Robot standing twisted.")
		time.sleep(3)

		# Now tell the robot to stand taller, using the same approach of constructing
		# a command message with the RobotCommandBuilder and issuing it with
		# robot_command.
		cmd = RobotCommandBuilder.synchro_stand_command(body_height=0.1)
		self.command_client.robot_command(cmd)
		self.robot.logger.info("Robot standing tall.")
		time.sleep(3)

	def set_default_body_control(self):
		"""Set default body control params to current body position"""
		footprint_R_body = geometry.EulerZXY()
		position = geo.Vec3(x=0.0, y=0.0, z=0.0)
		rotation = footprint_R_body.to_quaternion()
		pose = geo.SE3Pose(position=position, rotation=rotation)
		point = trajectory_pb2.SE3TrajectoryPoint(pose=pose)
		traj = trajectory_pb2.SE3Trajectory(points=[point])
		return spot_command_pb2.BodyControlParams(base_offset_rt_footprint=traj)

	def get_mobility_params(self):
		"""Gets mobility parameters for following"""
		vel_desired = .75
		speed_limit = geo.SE2VelocityLimit(
			max_vel=geo.SE2Velocity(linear=geo.Vec2(x=vel_desired, y=vel_desired), angular=.25))
		body_control = self.set_default_body_control()
		mobility_params = spot_command_pb2.MobilityParams(vel_limit=speed_limit, obstacle_params=None,
														body_control=body_control,
														locomotion_hint=spot_command_pb2.HINT_TROT)
		return mobility_params

	def get_go_to(self,x_goal,y_goal, robot_state, mobility_params, dist_margin=0.5):
		
		new_x_goal=vo_tform_robot.x+x_goal
		new_y_goal=vo_tform_robot.y+y_goal
		vo_tform_robot = get_vision_tform_body(robot_state.kinematic_state.transforms_snapshot)
		print(f"robot pos: {vo_tform_robot}")
		delta_ewrt_vo = np.array(
			[ new_x_goal- vo_tform_robot.x, new_y_goal - vo_tform_robot.y, 0])
		norm = np.linalg.norm(delta_ewrt_vo)
		if norm == 0:
			return None
		delta_ewrt_vo_norm = delta_ewrt_vo / norm
		heading = self._get_heading(delta_ewrt_vo_norm)
		vo_tform_goal = np.array([
			new_x_goal - delta_ewrt_vo_norm[0] * dist_margin,
			new_y_goal - delta_ewrt_vo_norm[1] * dist_margin
		])
		tag_cmd = RobotCommandBuilder.trajectory_command(goal_x=vo_tform_goal[0],
														goal_y=vo_tform_goal[1], goal_heading=heading,
														frame_name=VISION_FRAME_NAME,
														params=mobility_params)
		return tag_cmd


	def _get_heading(self,xhat):
		zhat = [0.0, 0.0, 1.0]
		yhat = np.cross(zhat, xhat)
		mat = np.array([xhat, yhat, zhat]).transpose()
		return Quat.from_matrix(mat).to_yaw()

	def power_off_spot(self):
		self.leaseKeep.shutdown()
		# Power the robot off. By specifying "cut_immediately=False", a safe power off command
		# is issued to the robot. This will attempt to sit the robot before powering off.
		self.robot.power_off(cut_immediately=False, timeout_sec=20)
		assert not self.robot.is_powered_on(), "Robot power off failed."
		self.robot.logger.info("Robot safely powered off.")

	def _update_thread(self,async_task):
		while True:
			async_task.update()
			time.sleep(0.01)

def main(argv):
	"""Command line interface."""
	parser = argparse.ArgumentParser()
	bosdyn.client.util.add_base_arguments(parser)
	# inbuiltCameras=False, camera_source=0,image_path=""
	parser.add_argument(
		'-c','--cameraSource',default='USB', help='Select the source to capture image. "USB" for USB camera and "SpotCams" for spot cameras'
	)
	parser.add_argument(
		'-i','--usbCameraSourceId',default=0, help='Select the USB camera Id to capture image. default is 0. Will use /dev/video0'
	)
	
	parser.add_argument(
		'--savePath', default=None, nargs='?', help=
		'Save the image captured by Spot to the provided directory. Invalid path saves to working directory.'
	)
	options = parser.parse_args(argv)
	print(f"host name:{options.hostname}")
	try:
		thisObj=SpotOperationWithYolo(options)
		
		thisObj.detect_and_operate(options.cameraSource,options.usbCameraSourceId)
		return True
	except Exception as exc:  # pylint: disable=broad-except
		logger = bosdyn.client.util.get_logger()
		logger.error("Spot operation with Yolo threw an exception: %r", exc)
		return False
	
if __name__ == '__main__':
    if not main(sys.argv[1:]):
        sys.exit(1)
